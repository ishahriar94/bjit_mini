
from datetime import timedelta
from odoo import models, fields, api
from odoo import api 
from odoo.exceptions import ValidationError
import re 

class productList(models.Model):
    _name = 'product.list'
    _description = 'Product Details'

    ##Sql Constraints To validate the Price Fileds Input. 
    _sql_constraints = [ 
        ('check_cost', 'CHECK(cost >= 0)', 'The cost must be strictly positive'),
        
        
    ]
    _sql_constraints = [ 
        ('check_sale_price', 'CHECK(sale_price >= 0)', 'The expected selling price must be positive')
        
    ]

    

    ## model creation
    pname = fields.Char(string='Product Name',required=False)
    avaiable_from = fields.Date(string='Available From')
    available_till = fields.Date(string='Available Till')
    description = fields.Char(string='Description')
    cost = fields.Float(string='Cost',required=True)
    sale_price = fields.Float(string='Sales Price',compute='total_cost',required=True)
    cus_sold = fields.Boolean(string='Can be Sold')
    cus_purchase = fields.Boolean(string='Can be Purchased')
    product_image = fields.Image(string="Upload", max_width=100, max_height=100, verify_resolution=False)
    status = fields.Selection([
        ('available','Available'),
        ('unavailable', 'Unavailable'),
        ('classified', 'Classified')
    ])
    country = fields.Selection([('option1', 'Bangladesh'), ('option2', 'United States'), ('option3', 'Canada')], string='Country')
    
    #automatically classified object 
    



    #naming Constraints for products
    @api.constrains('pname')
    def check_name_in_products(self):
        for rec in self:
            error = self.env['product.list'].search([('pname', '=', rec.pname)])
            if rec.pname == error:
                raise ValidationError(("Name %s Already Exists" % rec.pname))

    #onchange field for products
    @api.onchange('pname')
    def _onchange_status(self):
        #automatically classified object
        autoclass = ['Boing747', 'B12Bomber', 'Drone']
        for record in self:
            if record.pname == 'Boing747':     #we can make a list here
                self.status = 'classified'
    ##Computed Field Based on Taxation
    @api.depends('cost','country')
    def total_cost(self):
        if(self.country == 'option1'):
            for record in self:
                record.sale_price = (record.cost + (record.cost*0.5))
        if(self.country == 'option2'):
            for record in self:
                record.sale_price = (record.cost + (record.cost*0.1))
        else:
            for record in self:
                record.sale_price = (record.cost + (record.cost*0.7)) 




          


    

    
